import React from "react";
import './App.css';
import AgeCalculator from "./calculator/agecalculator";

function App() {
  return (
    <div className="App">
      <AgeCalculator />
    </div>
  );
}

export default App;
